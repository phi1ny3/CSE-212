# 1.
A = {1, 3, 5, 6, 7}
B = {1, 3, 2}
res = A.intersection(B)
print(res)
print(A)

#2.
print("index 1: 1, 33, 65 \nindex 2: 2 \nindex6: 54 \nindex8: 24 \nindex 9: 25, 57, 9 \nindex10: 42, 58 \nindex11: 75, 27 \nindex12: 12 \nindex13: 13 \nindex14: 46, 14")